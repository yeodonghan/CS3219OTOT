
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'yeodonghan',
  applicationName: 'otot',
  appUid: 'SC50fFfcyZ10N5P6Bq',
  orgUid: '966be632-07a0-4266-bb7a-08abb111790c',
  deploymentUid: '0ac7e863-ec9d-461e-a05a-de500bf410c5',
  serviceName: 'otot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'deploy',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'otot-deploy-hello', timeout: 15 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}