
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'yeodonghan',
  applicationName: 'otot',
  appUid: 'SC50fFfcyZ10N5P6Bq',
  orgUid: '966be632-07a0-4266-bb7a-08abb111790c',
  deploymentUid: '29b3f259-f417-49cb-8bd1-c8f9fa5099ca',
  serviceName: 'otot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'otot-dev-hello', timeout: 15 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}